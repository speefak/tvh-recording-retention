#!/usr/bin/env bash
# =============================================================================
# tvh-storage-cleanup
# Version: 0.8 (2026-03-27)
# Purpose: Tvheadend recording cleanup script - Safe + improved parsing
# =============================================================================

RECORDINGS_BASE="/mnt/fstab_virtiofs_tvh-storage/recordings"
CONFIG_FILE="/home/speefak/tvh-storage-cleanup.conf"
LOGFILE="/var/log/tvh-storage-cleanup.log"

show_usage() {
    echo "Usage: $0 [OPTION]"
    echo "  -r   Run cleanup"
    echo "  -e   Edit config"
    echo "  -s   Show config"
    echo "  -l   List recordings"
    echo "  -c   Setup cron"
    exit 1
}

create_default_config() {
    echo "Creating default config..." | tee -a "$LOGFILE"
    cat > "$CONFIG_FILE" << 'EOF'
# =============================================================================
# tvh-storage-cleanup.conf
# =============================================================================
Tagesschau          1   5
Tagesthemen         1   0
Tatort              1   0
Polizeiruf 110      1   0
Spacetime           1   0
Gute Zeiten schlechte Zeiten  7  10
EOF
}

edit_config() { echo "Opening config..."; sudo nano "$CONFIG_FILE"; exit 0; }
show_config() { echo "=== Config ==="; cat "$CONFIG_FILE" 2>/dev/null || echo "Not found"; exit 0; }
list_records() {
    sudo -u hts find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
         -printf '%TY-%Tm-%Td %TT %12s  %p\n' | sort -r
    exit 0
}

# ====================== MAIN ======================
if [ $# -eq 0 ]; then show_usage; fi

while getopts ":reslch" opt; do
    case $opt in
        r) RUN_CLEANUP=1 ;;
        e) edit_config ;;
        s) show_config ;;
        l) list_records ;;
        c) echo "Cron setup not implemented in this test version"; exit 0 ;;
        h) show_usage ;;
    esac
done

if [ "${RUN_CLEANUP:-0}" -ne 1 ]; then
    echo "Error: Use -r to run cleanup"
    exit 1
fi

echo "=== Tvheadend Storage Cleanup started: $(date) ===" | tee -a "$LOGFILE"

[ ! -f "$CONFIG_FILE" ] && create_default_config
[ ! -d "$RECORDINGS_BASE" ] && { echo "ERROR: Recordings path not found!"; exit 1; }

declare -a FILES_TO_DELETE=()
TOTAL_SIZE=0

echo "Reading config file..."

while IFS= read -r line || [ -n "$line" ]; do
    [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

    # ---------- Improved parsing ----------
    # Remove comments and trim
    line=$(echo "$line" | sed 's/#.*//; s/^[[:space:]]*//; s/[[:space:]]*$//')
    [ -z "$line" ] && continue

    # Last field = keep_count, second last = keep_days, rest = name
    KEEP_COUNT=$(echo "$line" | awk '{print $NF}')
    KEEP_DAYS=$(echo "$line" | awk '{print $(NF-1)}')
    SENDUNG=$(echo "$line" | awk '{for(i=1; i<NF-1; i++) printf "%s ", $i; print ""}' | sed 's/[[:space:]]*$//')

    if [[ -z "$SENDUNG" ]]; then
        echo "WARNING: Could not parse name in line: $line" | tee -a "$LOGFILE"
        continue
    fi

    echo "Processing: '$SENDUNG' → Days: $KEEP_DAYS | Keep last: $KEEP_COUNT" | tee -a "$LOGFILE"

    # Get all matching files, newest first
    FILELIST=$(mktemp)
    find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
         -iname "*${SENDUNG}*" -printf '%T@ %p\n' | sort -nr > "$FILELIST"

    # 1. Delete by age (keep_days)
    if [ "$KEEP_DAYS" -gt 0 ]; then
 #       echo "   → Deleting files older than $KEEP_DAYS day(s)" | tee -a "$LOGFILE"
        find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
             -iname "*${SENDUNG}*" -mtime +"$KEEP_DAYS" -print0 | \
        while IFS= read -r -d '' file; do
            FILES_TO_DELETE+=("$file")
            size=$(stat -c %s "$file" 2>/dev/null || echo 0)
            TOTAL_SIZE=$((TOTAL_SIZE + size))
            echo "    Marked (age): $file" | tee -a "$LOGFILE"
        done
    fi

    # 2. Keep only last X (keep_count)
    if [ "$KEEP_COUNT" -gt 0 ]; then
 #       echo "   → Keeping only last $KEEP_COUNT file(s)" | tee -a "$LOGFILE"
        tail -n +$((KEEP_COUNT + 1)) "$FILELIST" | while read -r ts file; do
            if [[ ! " ${FILES_TO_DELETE[*]} " =~ " ${file} " ]]; then
                FILES_TO_DELETE+=("$file")
                size=$(stat -c %s "$file" 2>/dev/null || echo 0)
                TOTAL_SIZE=$((TOTAL_SIZE + size))
                echo "    Marked (count): $file" | tee -a "$LOGFILE"
            fi
        done
    fi

    rm -f "$FILELIST"
done < "$CONFIG_FILE"

# ====================== SUMMARY ======================
echo "--------------------------------------------------"
echo "=== Summary ==="
echo "Files marked for deletion : ${#FILES_TO_DELETE[@]}"
echo "Estimated size            : $((TOTAL_SIZE / 1024 / 1024)) MB"
echo "--------------------------------------------------"

if [ ${#FILES_TO_DELETE[@]} -eq 0 ]; then
    echo "No files found to delete."
    echo "Tip: Check if filenames really contain the exact sendung name."
    exit 0
fi

# Confirmation + countdown (rm still commented for testing)
echo "rm commands are currently commented for testing."
echo "Found ${#FILES_TO_DELETE[@]} files that would be deleted."
echo "To enable deletion, remove the comments from the rm lines."
