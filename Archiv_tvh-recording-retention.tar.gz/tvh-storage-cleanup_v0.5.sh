#!/usr/bin/env bash
# =============================================================================
# tvh-storage-cleanup
# Version: 0.6 (2026-03-27)
# Purpose: Tvheadend recording cleanup script (Keep Days + Keep Last Count)
#
# Options:
#   -r   Run cleanup (delete files)
#   -e   Edit config file (nano)
#   -s   Show config file
#   -l   List all recordings
#   -c   Setup cron job
#   -h   Show this help
#
# Without any option → show help
# =============================================================================

RECORDINGS_BASE="/mnt/fstab_virtiofs_tvh-storage/recordings"
CONFIG_FILE="/home/speefak/tvh-storage-cleanup.conf"
LOGFILE="/var/log/tvh-storage-cleanup.log"

# ------------------- Helper Functions -------------------

show_usage() {
    echo "Usage: $0 [OPTION]"
    echo ""
    echo "Options:"
    echo "  -r   Run cleanup (delete old recordings)"
    echo "  -e   Edit config file with nano"
    echo "  -s   Show config file content"
    echo "  -l   List all recordings (newest first)"
    echo "  -c   Setup cron job"
    echo "  -h   Show this help"
    echo ""
    echo "Config format: <Recording Name> <keep_days> <keep_count>"
    echo "Example:       Tatort 21 6"
    echo "               Gute Zeiten schlechte Zeiten 7 10"
    exit 1
}

create_default_config() {
    echo "Config file not found. Creating default config..." | tee -a "$LOGFILE"
    cat > "$CONFIG_FILE" << 'EOF'
# =============================================================================
# tvh-storage-cleanup.conf
# Format: <Recording Name> <keep_days> <keep_count>
#
# Rules:
#   keep_days = 0  → Disable deletion by age (days)
#   keep_count = 0 → Disable "keep only last X recordings"
# =============================================================================

# ================== NEWS & MAGAZINES ==================
Tagesschau          3   12
Tagesthemen         3   10
heute journal       3   8

# ================== CRIME & SERIES ==================
Tatort             21   6
Polizeiruf 110     21   5
SOKO               14   8

# ================== DAILY SOAPS ==================
Gute Zeiten schlechte Zeiten   7   10
Alles was zählt                7   10

# ================== DOCUMENTARIES & REPORTS ==================
Doku               90   0
Terra X           180   0
Reportage          45   0

# ================== FALLBACK (everything else) ==================
#*                 60   0

EOF
    echo "Default config created: $CONFIG_FILE" | tee -a "$LOGFILE"
    echo "Edit it with: $0 -e" | tee -a "$LOGFILE"
}

edit_config() {
    echo "Opening config file for editing..."
    sudo nano "$CONFIG_FILE"
    exit 0
}

show_config() {
    echo "=== Content of $CONFIG_FILE ==="
    if [ -f "$CONFIG_FILE" ]; then
        cat "$CONFIG_FILE"
    else
        echo "Config file does not exist yet."
    fi
    exit 0
}

list_records() {
    echo "=== Tvheadend Recordings in $RECORDINGS_BASE ==="
    if [ ! -d "$RECORDINGS_BASE" ]; then
        echo "ERROR: Recording directory not found!"
        exit 1
    fi
    sudo -u hts find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
         -printf '%TY-%Tm-%Td %TT %12s  %p\n' | sort -r
    exit 0
}

setup_cron() {
    echo "=== Setting up Cron Job for tvh-storage-cleanup ==="
    read -p "Execution time (Hour:Minute) [Default: 1:00] → " TIME
    if [ -z "$TIME" ]; then
        HOUR=1
        MINUTE=0
    else
        HOUR=$(echo "$TIME" | cut -d: -f1)
        MINUTE=$(echo "$TIME" | cut -d: -f2)
    fi

    CRONLINE="$MINUTE $HOUR * * * /usr/local/bin/tvh-storage-cleanup -r"

    if sudo crontab -l 2>/dev/null | grep -q "tvh-storage-cleanup"; then
        echo "A cron job for this script already exists."
        read -p "Overwrite? (y/N) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo "Aborted."
            exit 0
        fi
        sudo crontab -l | grep -v "tvh-storage-cleanup" | sudo crontab -
    fi

    (sudo crontab -l 2>/dev/null; echo "# Tvheadend Cleanup - daily at ${HOUR}:${MINUTE}"; echo "$CRONLINE") | sudo crontab -
    echo "Cron job successfully created: $CRONLINE"
    echo "Log file: $LOGFILE"
    exit 0
}

# ------------------- Main Program -------------------

# No option given → show help
if [ $# -eq 0 ]; then
    show_usage
fi

# Parse options
while getopts ":reslch" opt; do
    case $opt in
        r) RUN_CLEANUP=1 ;;
        e) edit_config ;;
        s) show_config ;;
        l) list_records ;;
        c) setup_cron ;;
        h) show_usage ;;
        \?) echo "Invalid option: -$OPTARG"; show_usage ;;
    esac
done

# ------------------- Run Cleanup (only with -r) -------------------
if [ "${RUN_CLEANUP:-0}" -ne 1 ]; then
    echo "Error: Use option -r to run the cleanup."
    echo "Example: $0 -r"
    exit 1
fi

echo "=== Tvheadend Storage Cleanup started: $(date) ===" | tee -a "$LOGFILE"

if [ ! -f "$CONFIG_FILE" ]; then
    create_default_config
fi

if [ ! -d "$RECORDINGS_BASE" ]; then
    echo "ERROR: Recording directory not found: $RECORDINGS_BASE" | tee -a "$LOGFILE"
    exit 1
fi

echo "Recording directory: $RECORDINGS_BASE" | tee -a "$LOGFILE"
echo "Config file:         $CONFIG_FILE" | tee -a "$LOGFILE"
echo "--------------------------------------------------" | tee -a "$LOGFILE"

while IFS= read -r line || [ -n "$line" ]; do
    [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

    # Robust parsing: Last two fields = keep_days and keep_count
    # Everything before = recording name (can contain spaces)
    KEEP_COUNT=$(echo "$line" | awk '{print $NF}')
    KEEP_DAYS=$(echo "$line" | awk '{print $(NF-1)}')
    
    SENDUNG=$(echo "$line" | awk '{for(i=1; i<=NF-2; i++) printf "%s ", $i; print ""}' | sed 's/[[:space:]]*$//')

    if [[ -z "$SENDUNG" || -z "$KEEP_DAYS" || -z "$KEEP_COUNT" ]]; then
        echo "WARNING: Invalid line (too few fields) → $line" | tee -a "$LOGFILE"
        continue
    fi

    if ! [[ "$KEEP_DAYS" =~ ^[0-9]+$ ]] || ! [[ "$KEEP_COUNT" =~ ^[0-9]+$ ]]; then
        echo "WARNING: Invalid values (keep_days or keep_count not a number) → $line" | tee -a "$LOGFILE"
        continue
    fi

    if [ "$KEEP_DAYS" -eq 0 ] && [ "$KEEP_COUNT" -eq 0 ]; then
        echo "INFO: Both values are 0 → line ignored: $line" | tee -a "$LOGFILE"
        continue
    fi

    echo "Processing: '$SENDUNG' → Days: $KEEP_DAYS | Keep last: $KEEP_COUNT" | tee -a "$LOGFILE"

    FILELIST=$(mktemp)

    # Find matching files, sorted by modification time (newest first)
    find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
         -iname "*${SENDUNG}*" -printf '%T@ %p\n' | sort -nr > "$FILELIST"

    # 1. Delete files older than keep_days (if enabled)
    if [ "$KEEP_DAYS" -gt 0 ]; then
        echo "   → Deleting files older than $KEEP_DAYS days" | tee -a "$LOGFILE"
        find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
             -iname "*${SENDUNG}*" -mtime +"$KEEP_DAYS" -print0 | \
        while IFS= read -r -d '' file; do
            echo "    Delete (older than ${KEEP_DAYS} days): $file" | tee -a "$LOGFILE"
            rm -f "$file"
        done
    fi

    # 2. Keep only the last X recordings (works even if keep_days = 0)
    if [ "$KEEP_COUNT" -gt 0 ]; then
        echo "   → Keeping only the last $KEEP_COUNT recordings" | tee -a "$LOGFILE"
        tail -n +$((KEEP_COUNT + 1)) "$FILELIST" | while read -r ts file; do
            echo "    Delete (exceeds keep count ${KEEP_COUNT}): $file" | tee -a "$LOGFILE"
            rm -f "$file"
        done
    fi

    rm -f "$FILELIST"

done < "$CONFIG_FILE"

echo "--------------------------------------------------" | tee -a "$LOGFILE"
echo "=== Cleanup finished: $(date) ===" | tee -a "$LOGFILE"
