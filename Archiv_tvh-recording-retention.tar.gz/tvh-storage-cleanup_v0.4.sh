#!/usr/bin/env bash
# =============================================================================
# tvh-storage-cleanup
# Version: 0.4 (2026-03-27)
# Purpose: Tvheadend Aufnahmen-Aufräum-Script (Keep Days + Keep Count)
#
# Optionen:
#   -r   Run cleanup (Dateien löschen)
#   -e   Config-Datei bearbeiten (nano)
#   -s   Config-Datei anzeigen
#   -l   Alle Aufnahmen auflisten
#   -c   Cron-Job einrichten
#   -h   Diese Hilfe anzeigen
#
# Ohne Option → Hilfe anzeigen
# =============================================================================

RECORDINGS_BASE="/mnt/fstab_virtiofs_tvh-storage/recordings"
CONFIG_FILE="/home/speefak/tvh-storage-cleanup.conf"
LOGFILE="/var/log/tvh-storage-cleanup.log"

# ------------------- Hilfsfunktionen -------------------

show_usage() {
    echo "Usage: $0 [OPTION]"
    echo ""
    echo "Optionen:"
    echo "  -r   Cleanup ausführen (Dateien löschen)"
    echo "  -e   Config-Datei bearbeiten (nano)"
    echo "  -s   Config-Datei anzeigen"
    echo "  -l   Alle Aufnahmen auflisten"
    echo "  -c   Cron-Job einrichten"
    echo "  -h   Diese Hilfe anzeigen"
    echo ""
    exit 1
}

create_default_config() {
    echo "Config-Datei nicht gefunden. Erstelle Standard-Config..." | tee -a "$LOGFILE"
    cat > "$CONFIG_FILE" << 'EOF'
# =============================================================================
# tvh-storage-cleanup.conf
# Format: <Sendungsname> <keep_days> <keep_count>
#
# keep_days = 0   → Löschen nach Tagen deaktiviert
# keep_count = 0  → "Nur letzte X behalten" deaktiviert
# =============================================================================

# ================== NACHRICHTEN ==================
Tagesschau          3   12
Tagesthemen         3   10
heute journal       3   8

# ================== KRIMI / SERIEN ==================
Tatort             21   6
Polizeiruf 110     21   5

# ================== DAILY SOAPS ==================

# ================== DOKU & REPORTAGEN ==================

# ================== FALLBACK ==================
#*                  60   0

EOF
    echo "Standard-Config wurde erstellt: $CONFIG_FILE" | tee -a "$LOGFILE"
    echo "Passe sie bei Bedarf mit '$0 -e' an." | tee -a "$LOGFILE"
}

edit_config() {
    echo "Öffne Config-Datei zum Bearbeiten..."
    sudo nano "$CONFIG_FILE"
    exit 0
}

show_config() {
    echo "=== Inhalt von $CONFIG_FILE ==="
    if [ -f "$CONFIG_FILE" ]; then
        cat "$CONFIG_FILE"
    else
        echo "Config-Datei existiert noch nicht."
    fi
    exit 0
}

list_records() {
    echo "=== Tvheadend Aufnahmen in $RECORDINGS_BASE ==="
    if [ ! -d "$RECORDINGS_BASE" ]; then
        echo "FEHLER: Ordner nicht gefunden!"
        exit 1
    fi
    sudo -u hts find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
         -printf '%TY-%Tm-%Td %TT %12s  %p\n' | sort -r
    exit 0
}

setup_cron() {
    echo "=== Cron-Job für tvh-storage-cleanup einrichten ==="
    read -p "Uhrzeit (Stunde:Minute) [Default: 1:00] → " TIME
    if [ -z "$TIME" ]; then
        HOUR=1
        MINUTE=0
    else
        HOUR=$(echo "$TIME" | cut -d: -f1)
        MINUTE=$(echo "$TIME" | cut -d: -f2)
    fi

    CRONLINE="$MINUTE $HOUR * * * /usr/local/bin/tvh-storage-cleanup -r"

    if sudo crontab -l 2>/dev/null | grep -q "tvh-storage-cleanup"; then
        echo "Es existiert bereits ein Cron-Job für dieses Script."
        read -p "Überschreiben? (j/N) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Jj]$ ]]; then
            echo "Abgebrochen."
            exit 0
        fi
        sudo crontab -l | grep -v "tvh-storage-cleanup" | sudo crontab -
    fi

    (sudo crontab -l 2>/dev/null; echo "# Tvheadend Cleanup - täglich um ${HOUR}:${MINUTE}"; echo "$CRONLINE") | sudo crontab -
    echo "Cron-Job erfolgreich eingerichtet: $CRONLINE"
    echo "Das Script wird mit Option -r ausgeführt."
    echo "Log-Datei: $LOGFILE"
    exit 0
}

# ------------------- Hauptprogramm -------------------

# Keine Option angegeben → Hilfe anzeigen
if [ $# -eq 0 ]; then
    show_usage
fi

# Optionen parsen
while getopts ":reslch" opt; do
    case $opt in
        r) RUN_CLEANUP=1 ;;
        e) edit_config ;;
        s) show_config ;;
        l) list_records ;;
        c) setup_cron ;;
        h) show_usage ;;
        \?) echo "Ungültige Option: -$OPTARG"; show_usage ;;
    esac
done

# ------------------- Normales Cleanup (nur bei -r) -------------------
if [ "${RUN_CLEANUP:-0}" -ne 1 ]; then
    echo "Fehler: Für das Aufräumen muss die Option -r verwendet werden."
    echo "Beispiel: $0 -r"
    exit 1
fi

echo "=== Tvheadend Storage Cleanup gestartet: $(date) ===" | tee -a "$LOGFILE"

# Config automatisch erstellen, falls nicht vorhanden
if [ ! -f "$CONFIG_FILE" ]; then
    create_default_config
fi

if [ ! -d "$RECORDINGS_BASE" ]; then
    echo "FEHLER: Aufnahme-Ordner nicht gefunden: $RECORDINGS_BASE" | tee -a "$LOGFILE"
    exit 1
fi

echo "Aufnahme-Ordner: $RECORDINGS_BASE" | tee -a "$LOGFILE"
echo "Config-Datei:    $CONFIG_FILE" | tee -a "$LOGFILE"
echo "--------------------------------------------------" | tee -a "$LOGFILE"

while IFS= read -r line || [ -n "$line" ]; do
    [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

    SENDUNG=$(echo "$line" | awk '{print $1}')
    KEEP_DAYS=$(echo "$line" | awk '{print $2}')
    KEEP_COUNT=$(echo "$line" | awk '{print $3}')

    if [[ -z "$SENDUNG" || -z "$KEEP_DAYS" || -z "$KEEP_COUNT" ]]; then
        echo "WARNUNG: Ungültige Zeile → $line" | tee -a "$LOGFILE"
        continue
    fi

    if ! [[ "$KEEP_DAYS" =~ ^[0-9]+$ ]] || ! [[ "$KEEP_COUNT" =~ ^[0-9]+$ ]]; then
        echo "WARNUNG: Ungültige Werte → $line" | tee -a "$LOGFILE"
        continue
    fi

    if [ "$KEEP_DAYS" -eq 0 ] && [ "$KEEP_COUNT" -eq 0 ]; then
        echo "INFO: Beide Werte 0 → ignoriert: $line" | tee -a "$LOGFILE"
        continue
    fi

    echo "Verarbeite: '$SENDUNG' → Tage: $KEEP_DAYS | Letzte: $KEEP_COUNT" | tee -a "$LOGFILE"

    FILELIST=$(mktemp)

    # Dateien sortiert nach Änderungsdatum (neueste zuerst)
    find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
         -iname "*${SENDUNG}*" -printf '%T@ %p\n' | sort -nr > "$FILELIST"

    # 1. Nach Tagen löschen
    if [ "$KEEP_DAYS" -gt 0 ]; then
        find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
             -iname "*${SENDUNG}*" -mtime +"$KEEP_DAYS" -print0 | \
        while IFS= read -r -d '' file; do
            echo "    Lösche (älter als ${KEEP_DAYS} Tage): $file" | tee -a "$LOGFILE"
#            rm -f "$file"
        done
    fi

    # 2. Nur die letzten X Aufnahmen behalten
    if [ "$KEEP_COUNT" -gt 0 ]; then
        tail -n +$((KEEP_COUNT + 1)) "$FILELIST" | while read -r ts file; do
            echo "    Lösche (über Keep-Count ${KEEP_COUNT}): $file" | tee -a "$LOGFILE"
#            rm -f "$file"
        done
    fi

#   rm -f "$FILELIST"
done < "$CONFIG_FILE"

echo "--------------------------------------------------" | tee -a "$LOGFILE"
echo "=== Cleanup beendet: $(date) ===" | tee -a "$LOGFILE"
