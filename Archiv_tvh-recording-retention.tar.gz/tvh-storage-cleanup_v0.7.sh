#!/usr/bin/env bash
# =============================================================================
# tvh-storage-cleanup
# Version: 0.7 (2026-03-27)
# Purpose: Tvheadend recording cleanup script (Keep Days + Keep Last Count)
#
# Safety Features:
#   - Collects all files to be deleted first
#   - Shows summary + confirmation
#   - 10-second countdown with option to abort (press q)
# =============================================================================

RECORDINGS_BASE="/mnt/fstab_virtiofs_tvh-storage/recordings"
CONFIG_FILE="/home/speefak/tvh-storage-cleanup.conf"
LOGFILE="/var/log/tvh-storage-cleanup.log"

# ------------------- Helper Functions -------------------

show_usage() {
    echo "Usage: $0 [OPTION]"
    echo ""
    echo "Options:"
    echo "  -r   Run cleanup (delete old recordings)"
    echo "  -e   Edit config file with nano"
    echo "  -s   Show config file content"
    echo "  -l   List all recordings (newest first)"
    echo "  -c   Setup cron job"
    echo "  -h   Show this help"
    echo ""
    echo "Config format: <Recording Name> <keep_days> <keep_count>"
    exit 1
}

create_default_config() {
    echo "Config file not found. Creating default config..." | tee -a "$LOGFILE"
    cat > "$CONFIG_FILE" << 'EOF'
# =============================================================================
# tvh-storage-cleanup.conf
# Format: <Recording Name> <keep_days> <keep_count>
#
# keep_days = 0  → Disable deletion by age
# keep_count = 0 → Disable "keep only last X"
# =============================================================================

# ================== NEWS & MAGAZINES ==================
Tagesschau          3   12
Tagesthemen         3   10
heute journal       3   8

# ================== CRIME & SERIES ==================
Tatort             21   6
Polizeiruf 110     21   5

# ================== DAILY SOAPS ==================
Gute Zeiten schlechte Zeiten   7   10
Alles was zählt                7   10

# ================== DOCUMENTARIES ==================
Doku               90   0
Terra X           180   0

# ================== FALLBACK ==================
#*                 60   0
EOF
    echo "Default config created: $CONFIG_FILE" | tee -a "$LOGFILE"
}

edit_config() {
    echo "Opening config file for editing..."
    sudo nano "$CONFIG_FILE"
    exit 0
}

show_config() {
    echo "=== Content of $CONFIG_FILE ==="
    if [ -f "$CONFIG_FILE" ]; then
        cat "$CONFIG_FILE"
    else
        echo "Config file does not exist yet."
    fi
    exit 0
}

list_records() {
    echo "=== Tvheadend Recordings in $RECORDINGS_BASE ==="
    if [ ! -d "$RECORDINGS_BASE" ]; then
        echo "ERROR: Recording directory not found!"
        exit 1
    fi
    sudo -u hts find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
         -printf '%TY-%Tm-%Td %TT %12s  %p\n' | sort -r
    exit 0
}

setup_cron() {
    echo "=== Setting up Cron Job ==="
    read -p "Execution time (Hour:Minute) [Default: 1:00] → " TIME
    if [ -z "$TIME" ]; then
        HOUR=1
        MINUTE=0
    else
        HOUR=$(echo "$TIME" | cut -d: -f1)
        MINUTE=$(echo "$TIME" | cut -d: -f2)
    fi

    CRONLINE="$MINUTE $HOUR * * * /usr/local/bin/tvh-storage-cleanup -r"

    if sudo crontab -l 2>/dev/null | grep -q "tvh-storage-cleanup"; then
        echo "A cron job already exists."
        read -p "Overwrite? (y/N) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo "Aborted."
            exit 0
        fi
        sudo crontab -l | grep -v "tvh-storage-cleanup" | sudo crontab -
    fi

    (sudo crontab -l 2>/dev/null; echo "# Tvheadend Cleanup - daily at ${HOUR}:${MINUTE}"; echo "$CRONLINE") | sudo crontab -
    echo "Cron job created: $CRONLINE"
    exit 0
}

# ------------------- Main Cleanup (only with -r) -------------------
if [ "${RUN_CLEANUP:-0}" -ne 1 ]; then
    echo "Error: Use -r to run cleanup."
    exit 1
fi

echo "=== Tvheadend Storage Cleanup started: $(date) ===" | tee -a "$LOGFILE"

if [ ! -f "$CONFIG_FILE" ]; then
    create_default_config
fi

if [ ! -d "$RECORDINGS_BASE" ]; then
    echo "ERROR: Recording directory not found!" | tee -a "$LOGFILE"
    exit 1
fi

echo "Recording directory: $RECORDINGS_BASE" | tee -a "$LOGFILE"
echo "Config file:         $CONFIG_FILE" | tee -a "$LOGFILE"
echo "--------------------------------------------------" | tee -a "$LOGFILE"

declare -a FILES_TO_DELETE=()
TOTAL_SIZE=0

while IFS= read -r line || [ -n "$line" ]; do
    [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

    KEEP_COUNT=$(echo "$line" | awk '{print $NF}')
    KEEP_DAYS=$(echo "$line" | awk '{print $(NF-1)}')
    SENDUNG=$(echo "$line" | awk '{for(i=1; i<=NF-2; i++) printf "%s ", $i; print ""}' | sed 's/[[:space:]]*$//')

    if [[ -z "$SENDUNG" || -z "$KEEP_DAYS" || -z "$KEEP_COUNT" ]]; then
        echo "WARNING: Invalid line → $line" | tee -a "$LOGFILE"
        continue
    fi

    if ! [[ "$KEEP_DAYS" =~ ^[0-9]+$ ]] || ! [[ "$KEEP_COUNT" =~ ^[0-9]+$ ]]; then
        echo "WARNING: Invalid numbers → $line" | tee -a "$LOGFILE"
        continue
    fi

    if [ "$KEEP_DAYS" -eq 0 ] && [ "$KEEP_COUNT" -eq 0 ]; then
        continue
    fi

    echo "Processing: '$SENDUNG' → Days: $KEEP_DAYS | Keep last: $KEEP_COUNT" | tee -a "$LOGFILE"

    # Temporäre Liste aller passenden Dateien (neueste zuerst)
    FILELIST=$(mktemp)
    find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
         -iname "*${SENDUNG}*" -printf '%T@ %p\n' | sort -nr > "$FILELIST"

    # =============================================
    # 1. FIRST: Delete by days (if keep_days > 0)
    # =============================================
    if [ "$KEEP_DAYS" -gt 0 ]; then
        echo "   → Step 1: Deleting files older than $KEEP_DAYS days" | tee -a "$LOGFILE"
        find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
             -iname "*${SENDUNG}*" -mtime +"$KEEP_DAYS" -print0 | \
        while IFS= read -r -d '' file; do
            FILES_TO_DELETE+=("$file")
            size=$(stat -c %s "$file" 2>/dev/null || echo 0)
            TOTAL_SIZE=$((TOTAL_SIZE + size))
            echo "    Marked (older than ${KEEP_DAYS} days): $file" | tee -a "$LOGFILE"
        done
    fi

    # =============================================
    # 2. SECOND: Keep only last X files (if keep_count > 0)
    #    This runs on the CURRENT files (after day deletion)
    # =============================================
    if [ "$KEEP_COUNT" -gt 0 ]; then
        echo "   → Step 2: Keeping only the last $KEEP_COUNT recordings" | tee -a "$LOGFILE"
        tail -n +$((KEEP_COUNT + 1)) "$FILELIST" | while read -r ts file; do
            # Only mark if not already marked by day deletion
            if [[ ! " ${FILES_TO_DELETE[*]} " =~ " ${file} " ]]; then
                FILES_TO_DELETE+=("$file")
                size=$(stat -c %s "$file" 2>/dev/null || echo 0)
                TOTAL_SIZE=$((TOTAL_SIZE + size))
                echo "    Marked (exceeds keep count ${KEEP_COUNT}): $file" | tee -a "$LOGFILE"
            fi
        done
    fi

    rm -f "$FILELIST"
done < "$CONFIG_FILE"

# ====================== SUMMARY & CONFIRMATION ======================
echo "--------------------------------------------------" | tee -a "$LOGFILE"
echo "=== Cleanup Summary ===" | tee -a "$LOGFILE"
echo "Files marked for deletion : ${#FILES_TO_DELETE[@]}" | tee -a "$LOGFILE"
echo "Total size                : $((TOTAL_SIZE / 1024 / 1024)) MB" | tee -a "$LOGFILE"
echo "--------------------------------------------------"

if [ ${#FILES_TO_DELETE[@]} -eq 0 ]; then
    echo "No files to delete."
    echo "=== Cleanup finished: $(date) ===" | tee -a "$LOGFILE"
    exit 0
fi

echo ""
echo "Do you really want to DELETE these ${#FILES_TO_DELETE[@]} files?"
echo "Press 'q' + Enter to abort, or wait 10 seconds to continue."
echo ""

# 10-second countdown with abort
for i in {10..1}; do
    echo -ne "Deleting in $i seconds... (press q + Enter to cancel) \r"
    read -t 1 -n 1 -s key 2>/dev/null
    if [[ $key == "q" || $key == "Q" ]]; then
        echo -e "\n\nDeletion aborted by user."
        echo "Deletion aborted by user." | tee -a "$LOGFILE"
        exit 0
    fi
done

echo -e "\n\nStarting deletion now...\n"

# ====================== ACTUAL DELETION ======================
for file in "${FILES_TO_DELETE[@]}"; do
    if [ -f "$file" ]; then
        echo "Deleting: $file" | tee -a "$LOGFILE"
#        rm -f "$file"
    fi
done

echo "=== Cleanup finished: $(date) ===" | tee -a "$LOGFILE"
echo "Successfully deleted ${#FILES_TO_DELETE[@]} files."
