#!/usr/bin/env bash
# =============================================================================
# tvh-storage-cleanup
# Version: 0.9 (2026-03-27)
# Purpose: Tvheadend recording cleanup script
# =============================================================================

RECORDINGS_BASE="/mnt/fstab_virtiofs_tvh-storage/recordings"
CONFIG_FILE="/home/speefak/tvh-storage-cleanup.conf"
LOGFILE="/var/log/tvh-storage-cleanup.log"

show_usage() {
    echo "Usage: $0 [OPTION]"
    echo "  -r   Run cleanup"
    echo "  -e   Edit config file"
    echo "  -s   Show config file"
    echo "  -l   List all recordings"
    echo "  -h   Show help"
    exit 1
}

create_default_config() {
    echo "Creating default config..." | tee -a "$LOGFILE"
    cat > "$CONFIG_FILE" << 'EOF'
# =============================================================================
Tagesschau          1   5
Tagesthemen         1   0
Tatort              1   0
Polizeiruf 110      1   0
Spacetime           1   0
Gute Zeiten schlechte Zeiten  7  10
EOF
}

edit_config() { echo "Opening config..."; sudo nano "$CONFIG_FILE"; exit 0; }
show_config() { echo "=== Config ==="; cat "$CONFIG_FILE" 2>/dev/null || echo "Not found"; exit 0; }
list_records() {
    echo "=== Recordings ==="
    sudo -u hts find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
         -printf '%TY-%Tm-%Td %TT %12s  %p\n' | sort -r
    exit 0
}

# ====================== MAIN ======================
if [ $# -eq 0 ]; then show_usage; fi

while getopts ":reslh" opt; do
    case $opt in
        r) RUN_CLEANUP=1 ;;
        e) edit_config ;;
        s) show_config ;;
        l) list_records ;;
        h) show_usage ;;
        \?) echo "Invalid option"; show_usage ;;
    esac
done

if [ "${RUN_CLEANUP:-0}" -ne 1 ]; then
    echo "Error: Use -r to run cleanup"
    exit 1
fi

echo "=== Tvheadend Storage Cleanup started: $(date) ===" | tee -a "$LOGFILE"

[ ! -f "$CONFIG_FILE" ] && create_default_config
[ ! -d "$RECORDINGS_BASE" ] && { echo "ERROR: Recording directory not found!"; exit 1; }

declare -a FILES_TO_DELETE=()
TOTAL_SIZE=0

echo "Reading config and searching for files to delete..."

while IFS= read -r line || [ -n "$line" ]; do
    [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

    line=$(echo "$line" | sed 's/#.*//; s/^[[:space:]]*//; s/[[:space:]]*$//')
    [ -z "$line" ] && continue

    KEEP_COUNT=$(echo "$line" | awk '{print $NF}')
    KEEP_DAYS=$(echo "$line" | awk '{print $(NF-1)}')
    SENDUNG=$(echo "$line" | awk '{for(i=1; i<NF-1; i++) printf "%s ", $i; print ""}' | sed 's/[[:space:]]*$//')

    if [[ -z "$SENDUNG" ]]; then
        echo "WARNING: Could not parse line: $line" | tee -a "$LOGFILE"
        continue
    fi

    echo "Processing: '$SENDUNG' → Days: $KEEP_DAYS | Keep last: $KEEP_COUNT" | tee -a "$LOGFILE"

    # 1. Delete by age (keep_days)
    if [ "$KEEP_DAYS" -gt 0 ]; then
        echo "   → Searching files older than $KEEP_DAYS day(s)..." | tee -a "$LOGFILE"
        find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
             -iname "*${SENDUNG}*" -mtime +"$KEEP_DAYS" -print0 | \
        while IFS= read -r -d '' file; do
            FILES_TO_DELETE+=("$file")
            size=$(stat -c %s "$file" 2>/dev/null || echo 0)
            TOTAL_SIZE=$((TOTAL_SIZE + size))
            echo "    Marked (age): $file" | tee -a "$LOGFILE"
        done
    fi

    # 2. Keep only last X files
    if [ "$KEEP_COUNT" -gt 0 ]; then
        echo "   → Keeping only the last $KEEP_COUNT file(s)..." | tee -a "$LOGFILE"
        FILELIST=$(mktemp)
        find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
             -iname "*${SENDUNG}*" -printf '%T@ %p\n' | sort -nr > "$FILELIST"

        tail -n +$((KEEP_COUNT + 1)) "$FILELIST" | while read -r ts file; do
            if [[ ! " ${FILES_TO_DELETE[*]} " =~ " ${file} " ]]; then
                FILES_TO_DELETE+=("$file")
                size=$(stat -c %s "$file" 2>/dev/null || echo 0)
                TOTAL_SIZE=$((TOTAL_SIZE + size))
                echo "    Marked (count limit): $file" | tee -a "$LOGFILE"
            fi
        done
        rm -f "$FILELIST"
    fi

done < "$CONFIG_FILE"

# ====================== SUMMARY ======================
echo "--------------------------------------------------"
echo "=== Summary ==="
echo "Files marked for deletion : ${#FILES_TO_DELETE[@]}"
echo "Total size                : $((TOTAL_SIZE / 1024 / 1024)) MB"
echo "--------------------------------------------------"

if [ ${#FILES_TO_DELETE[@]} -eq 0 ]; then
    echo "No files found to delete."
    echo "→ Check if the sendung names in config match parts of your filenames."
    echo "→ Try running: $0 -l  to see your actual file names"
    exit 0
fi

echo ""
echo "The script will now delete ${#FILES_TO_DELETE[@]} files."
echo "Press 'q' + Enter to abort, or wait 10 seconds to proceed with deletion."

for i in {10..1}; do
    echo -ne " → Deletion in $i seconds... (q = cancel) \r"
    read -t 1 -n 1 -s key 2>/dev/null
    if [[ $key == "q" || $key == "Q" ]]; then
        echo -e "\n\nDeletion aborted by user."
        exit 0
    fi
done

echo -e "\n\nStarting deletion...\n"

for file in "${FILES_TO_DELETE[@]}"; do
    if [ -f "$file" ]; then
        echo "Deleting: $file" | tee -a "$LOGFILE"
echo "        rm -f "$file""
    fi
done

echo "=== Cleanup finished: $(date) ===" | tee -a "$LOGFILE"
echo "Successfully deleted ${#FILES_TO_DELETE[@]} files."
