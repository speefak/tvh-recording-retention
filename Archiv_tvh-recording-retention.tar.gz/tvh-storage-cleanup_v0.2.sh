#!/usr/bin/env bash
# =============================================================================
# tvh-storage-cleanup
# Version: 0.2   (2025-03-27)
# Purpose:   Tvheadend Aufnahmen-Aufräum-Script (Keep Days + Keep Count)         
#
# Author:    (your name / adapted with Grok)
# License:   MIT / Free use & redistribution
#
# ================================================================
# Config-Format:  <Sendungsname> <keep_days> <keep_count>
#
# Regeln:
# - keep_days = 0   → Tage-Funktion deaktiviert
# - keep_count = 0  → Anzahl-Funktion deaktiviert
# - Beide 0 → Zeile wird ignoriert
#
# Optionen:
#   -e   → Config-Datei bearbeiten (nano)
#   -s   → Config-Datei anzeigen
#   -l   → Alle Aufnahmen auflisten (mit Datum & Größe)
#   -c   → Cron-Job einrichten (fragt nach Uhrzeit, Default 1:00)
#
# Ohne Option → normales Cleanup ausführen
# ================================================================

RECORDINGS_BASE="/mnt/fstab_virtiofs_tvh-storage/recordings"
#CONFIG_FILE="/var/lib/tvheadend/tvh-storage-cleanup.conf"
CONFIG_FILE="/home/speefak/tvh-storage-cleanup.conf"
LOGFILE="/var/log/tvh-storage-cleanup.log"

# ------------------- Hilfsfunktionen -------------------

show_usage() {
    echo "Usage: $0 [-e | -s | -l | -c]"
    echo "  -e   Edit config file"
    echo "  -s   Show config file"
    echo "  -l   List all recordings"
    echo "  -c   Setup cron job"
    echo "  (no option)  Run cleanup"
    exit 1
}

edit_config() {
    echo "Öffne Config-Datei zum Bearbeiten..."
    sudo nano "$CONFIG_FILE"
    exit 0
}

show_config() {
    echo "=== Inhalt von $CONFIG_FILE ==="
    if [ -f "$CONFIG_FILE" ]; then
        cat "$CONFIG_FILE"
    else
        echo "Config-Datei existiert noch nicht."
    fi
    exit 0
}

list_records() {
    echo "=== Tvheadend Aufnahmen ($RECORDINGS_BASE) ==="
    if [ ! -d "$RECORDINGS_BASE" ]; then
        echo "Ordner nicht gefunden!"
        exit 1
    fi
    sudo -u hts find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
         -printf '%TY-%Tm-%Td %TT %12s  %p\n' | sort -r
    exit 0
}

setup_cron() {
    echo "=== Cron-Job für tvh-storage-cleanup einrichten ==="
    read -p "Uhrzeit (Stunde:Minute) [Default: 1:00] → " TIME
    if [ -z "$TIME" ]; then
        HOUR=1
        MINUTE=0
    else
        HOUR=$(echo "$TIME" | cut -d: -f1)
        MINUTE=$(echo "$TIME" | cut -d: -f2)
    fi

    # Cron-Zeile erstellen
    CRONLINE="$MINUTE $HOUR * * * /usr/local/bin/tvh-storage-cleanup"

    # Prüfen ob schon vorhanden
    if sudo crontab -l 2>/dev/null | grep -q "tvh-storage-cleanup"; then
        echo "Es existiert bereits ein Cron-Job für dieses Script."
        read -p "Überschreiben? (j/N) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Jj]$ ]]; then
            echo "Abgebrochen."
            exit 0
        fi
        sudo crontab -l | grep -v "tvh-storage-cleanup" | sudo crontab -
    fi

    # Neuen Job hinzufügen
    (sudo crontab -l 2>/dev/null; echo "# Tvheadend Cleanup - täglich um $HOUR:$MINUTE"; echo "$CRONLINE") | sudo crontab -
    echo "Cron-Job erfolgreich eingerichtet: $CRONLINE"
    echo "Log: $LOGFILE"
    exit 0
}

# ------------------- Optionen parsen -------------------

while getopts ":eslc" opt; do
    case $opt in
        e) edit_config ;;
        s) show_config ;;
        l) list_records ;;
        c) setup_cron ;;
        \?) echo "Ungültige Option: -$OPTARG"; show_usage ;;
    esac
done

# ------------------- Normales Cleanup -------------------

echo "=== Tvheadend Storage Cleanup gestartet: $(date) ===" | tee -a "$LOGFILE"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "FEHLER: Config-Datei nicht gefunden: $CONFIG_FILE" | tee -a "$LOGFILE"
    echo "Erstelle sie mit -e oder manuell." | tee -a "$LOGFILE"
    exit 1
fi

if [ ! -d "$RECORDINGS_BASE" ]; then
    echo "FEHLER: Aufnahme-Ordner nicht gefunden: $RECORDINGS_BASE" | tee -a "$LOGFILE"
    exit 1
fi

echo "Aufnahme-Ordner: $RECORDINGS_BASE" | tee -a "$LOGFILE"
echo "--------------------------------------------------" | tee -a "$LOGFILE"

while IFS= read -r line || [ -n "$line" ]; do
    [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

    # Drei Felder parsen: Sendung, keep_days, keep_count
    SENDUNG=$(echo "$line" | awk '{print $1}')
    KEEP_DAYS=$(echo "$line" | awk '{print $2}')
    KEEP_COUNT=$(echo "$line" | awk '{print $3}')

    # Gültigkeitsprüfung
    if [[ -z "$SENDUNG" || -z "$KEEP_DAYS" || -z "$KEEP_COUNT" ]]; then
        echo "WARNUNG: Ungültige Zeile (zu wenige Felder) → $line" | tee -a "$LOGFILE"
        continue
    fi

    if ! [[ "$KEEP_DAYS" =~ ^[0-9]+$ ]] || ! [[ "$KEEP_COUNT" =~ ^[0-9]+$ ]]; then
        echo "WARNUNG: Ungültige Werte (keine Zahlen) → $line" | tee -a "$LOGFILE"
        continue
    fi

    if [ "$KEEP_DAYS" -eq 0 ] && [ "$KEEP_COUNT" -eq 0 ]; then
        echo "INFO: Beide Werte 0 → Zeile ignoriert: $line" | tee -a "$LOGFILE"
        continue
    fi

    echo "Verarbeite: '$SENDUNG' → Tage: $KEEP_DAYS | Count: $KEEP_COUNT" | tee -a "$LOGFILE"

    # Temporäre Dateiliste für diese Sendung
    FILELIST=$(mktemp)

    # Alle passenden Dateien finden und nach Änderungsdatum sortieren (neueste zuerst)
    find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
         -iname "*${SENDUNG}*" -printf '%T@ %p\n' | sort -nr > "$FILELIST"

    # 1. Nach Tagen löschen (falls aktiviert)
    if [ "$KEEP_DAYS" -gt 0 ]; then
        find "$RECORDINGS_BASE" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) \
             -iname "*${SENDUNG}*" -mtime +"$KEEP_DAYS" -print0 | \
        while IFS= read -r -d '' file; do
            echo "    Lösche (älter als ${KEEP_DAYS} Tage): $file" | tee -a "$LOGFILE"
            echo "rm -f "$file""
        done
    fi

    # 2. Nur die letzten X Aufnahmen behalten (falls aktiviert)
    if [ "$KEEP_COUNT" -gt 0 ]; then
        tail -n +$((KEEP_COUNT + 1)) "$FILELIST" | while read -r ts file; do
            echo "    Lösche (über Keep-Count ${KEEP_COUNT}): $file" | tee -a "$LOGFILE"
            echo "rm -f "$file""
        done
    fi

   echo " rm -f "$FILELIST""

done < "$CONFIG_FILE"

echo "--------------------------------------------------" | tee -a "$LOGFILE"
echo "=== Cleanup beendet: $(date) ===" | tee -a "$LOGFILE"
