#!/bin/bash
# =============================================
# Tvheadend Cleanup-Script
# Löscht Aufnahmen älter als X Tage pro Sendung
# =============================================

# === EINSTELLUNGEN ===
RECORDINGS_BASE="/mnt/fstab_virtiofs_tvh-storage/recordings"    # ← HIER ANPASSEN! z.B. /home/tvheadend/recordings oder /media/recordings
CONFIG_FILE="/var/lib/tvheadend/tvh-storage-cleanup.conf"      	# ← Pfad zu deiner Config-Datei => <Aufnahme Name> <keeptime>


# show recordings sudo -u hts find $RECORDINGS_BASE

# Optional: Nur bestimmte Dateiendungen löschen (sicherer)
FILE_TYPES="*.ts *.mkv *.mp4"

# Logging
LOGFILE="/var/log/tvheadend-cleanup.log"

echo "=== Tvheadend Cleanup gestartet: $(date) ===" | tee -a "$LOGFILE"

# Config prüfen
if [ ! -f "$CONFIG_FILE" ]; then
    echo "FEHLER: Config-Datei $CONFIG_FILE nicht gefunden!" | tee -a "$LOGFILE"
    exit 1
fi

# Jede Zeile der Config verarbeiten
while IFS= read -r line || [ -n "$line" ]; do
    # Leere Zeilen und Kommentare (#) ignorieren
    [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

    # Sendungsname und Tage trennen (letztes Wort = Tage, Rest = Name)
    KEEPTIME=$(echo "$line" | awk '{print $NF}')
    SENDUNG=$(echo "$line" | awk '{$NF=""; print $0}' | sed 's/[[:space:]]*$//')

    # Nur wenn beides vorhanden ist
    if [[ -z "$SENDUNG" || -z "$KEEPTIME" || ! "$KEEPTIME" =~ ^[0-9]+$ ]]; then
        echo "Ungültige Zeile übersprungen: $line" | tee -a "$LOGFILE"
        continue
    fi 

    # Ordner suchen (Tvheadend escaped oft / und Sonderzeichen → wir suchen mit * )
    echo "Verarbeite: '$SENDUNG' → behalte $KEEPTIME Tage" | tee -a "$LOGFILE"

# bis hier ok   

    echo fuck
    # Alle Unterordner finden, die den Sendungsnamen enthalten (case-insensitive)
    find "$RECORDINGS_BASE" -type d -iname "*${SENDUNG}*" 2>/dev/null | while read -r DIR; do
    
    echo fuck2
    
        if [ -d "$DIR" ]; then
            echo "  → Ordner gefunden: $DIR" | tee -a "$LOGFILE"

            # Alte Dateien löschen (älter als KEEPTIME Tage)
            find "$DIR" -type f \( -name "*.ts" -o -name "*.mkv" -o -name "*.mp4" \) -mtime +"$KEEPTIME" -print0 | \
            while IFS= read -r -d '' file; do
                echo "    Lösche (älter als ${KEEPTIME} Tage): $file" | tee -a "$LOGFILE"
                rm -f "$file"
            done
        fi
    done
done < "$CONFIG_FILE"

echo "=== Cleanup beendet: $(date) ===" | tee -a "$LOGFILE"
